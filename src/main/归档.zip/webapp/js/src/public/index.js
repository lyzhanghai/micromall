/**
 * Created by kangdaye on 16/5/14.
 */
'use strict';
var TabSelector = require('src/core/TabSelector.jsx');
var React = require('react');

var data = [
    {name: 'Red', value: 'red'},
    {name: 'Blue', value: 'blue'},
    {name: 'Yellow', value: 'yellow'},
    {name: 'Green', value: 'green'},
    {name: 'White', value: 'White'}
];


React.render(
    TabSelector({label: 'Color', data: data, selected: null}),
    document.getElementById('banner')
);