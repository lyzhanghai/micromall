/**
 * Created by kangdaye on 16/5/13.
 */
'use strict';
// require('../css/style.css');
// var TabSelector = require('libs/TabSelector.jsx');
// var React = require('libs/react');
require('weight/bodySize');
require('src/public/index');


// var data = [
//     {name: 'Red', value: 'red'},
//     {name: 'Blue', value: 'blue'},
//     {name: 'Yellow', value: 'yellow'},
//     {name: 'Green', value: 'green'},
//     {name: 'White', value: 'White'}
// ];
//
// // var node = document.createElement('div');
// // document.body.appendChild(node);
// React.render(
//     TabSelector({label: 'Color', data: data, selected: null}),
//     document.getElementById('container')
// );