var webpack = require('webpack');
var path = require('path');

module.exports = {
  // context : __dirname,
  // entry: './js/entry.js',
  entry: [
    'webpack-dev-server/client?http://127.0.0.1:3000', // WebpackDevServer host and port
    'webpack/hot/only-dev-server',
     path.join(__dirname,"/webapp/js/src/app.js")
  ],
  output: {
    path: __dirname,
    filename: 'bundle.js',
    publicPath: 'http://127.0.0.1:3000/webapp/js/tools/'
  },
  module: {
    loaders: [
      { test: /\.css$/, loader: 'style!css' },
      { test: /\.jsx$/, loaders: ['react-hot', 'jsx?harmony'], exclude: /node_modules/ }
    ]
  },
  resolve: {
    extensions: ['', '.js', '.jsx'],
    alias: {
      libs: __dirname + '/webapp/js/tools/libs/',
      weight: __dirname + '/webapp/js/tools/weight/',
      src: __dirname + '/webapp/js/src/'
    }
  },
  watch: true,
  plugins: [
    new webpack.HotModuleReplacementPlugin(),
    new webpack.NoErrorsPlugin()
  ]
};